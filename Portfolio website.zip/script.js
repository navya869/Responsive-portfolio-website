(function () {
  "use strict";
  var root = document.documentElement;
  var themeBtn = document.getElementById("themeBtn");
  var menuBtn = document.getElementById("menuBtn");
  var navLinks = document.getElementById("navLinks");

  /* ----- Theme: saved choice, else system preference ----- */
  function getSaved() {
    try { return localStorage.getItem("theme"); } catch (e) { return null; }
  }
  function applyTheme(theme) {
    root.setAttribute("data-theme", theme);
    themeBtn.setAttribute("aria-label", theme === "dark" ? "Switch to light mode" : "Switch to dark mode");
  }
  var initial = getSaved() || (window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light");
  applyTheme(initial);

  themeBtn.addEventListener("click", function () {
    var next = root.getAttribute("data-theme") === "dark" ? "light" : "dark";
    applyTheme(next);
    try { localStorage.setItem("theme", next); } catch (e) {}
  });

  /* ----- Mobile menu ----- */
  menuBtn.addEventListener("click", function () {
    var open = navLinks.classList.toggle("open");
    menuBtn.setAttribute("aria-expanded", String(open));
  });
  navLinks.addEventListener("click", function (e) {
    if (e.target.tagName === "A") {
      navLinks.classList.remove("open");
      menuBtn.setAttribute("aria-expanded", "false");
    }
  });

  /* ----- Highlight current section in nav ----- */
  var links = navLinks.querySelectorAll("a");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          links.forEach(function (a) {
            a.classList.toggle("active", a.getAttribute("href") === "#" + entry.target.id);
          });
        }
      });
    }, { rootMargin: "-40% 0px -55% 0px" });
    document.querySelectorAll("main section[id]").forEach(function (s) { io.observe(s); });
  }

  /* ----- Contact form validation ----- */
  var form = document.getElementById("contactForm");
  var status = document.getElementById("status");
  form.addEventListener("submit", function (e) {
    e.preventDefault();
    var fields = form.querySelectorAll("input, textarea");
    var valid = true;
    fields.forEach(function (f) {
      var ok = f.value.trim() !== "" && (f.type !== "email" || /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(f.value));
      f.classList.toggle("invalid", !ok);
      f.setAttribute("aria-invalid", String(!ok));
      if (!ok) valid = false;
    });
    status.className = "status " + (valid ? "ok" : "error");
    status.textContent = valid
      ? "Thanks, your message is ready to send. Connect this form to a backend to deliver it."
      : "Fill in every field with a valid email address.";
    if (valid) form.reset();
  });

  document.getElementById("year").textContent = new Date().getFullYear();
})();
